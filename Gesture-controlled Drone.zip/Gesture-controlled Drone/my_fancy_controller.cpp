#include "ros/ros.h"
#include "sensor_msgs/Imu.h"
#include "geometry_msgs/Twist.h"
#include "tf/tf.h"

#define no_ward 	control_aray.linear.x =  0;
#define forward 	control_aray.linear.x =  1;
#define backward 	control_aray.linear.x = -1;
#define no_strafe 	control_aray.linear.y =  0;
#define move_right 	control_aray.linear.y = -1;
#define move_left 	control_aray.linear.y = 1;
#define no_elavation 	control_aray.linear.z =  0;
#define up 		control_aray.linear.z =  1;
#define down 		control_aray.linear.z = -1;
#define no_turn 	control_aray.angular.z =  0;
#define turn_right 	control_aray.angular.z =  -1;
#define turn_left 	control_aray.angular.z = 1;

geometry_msgs::Twist control_aray;

	int imuR_x_pos = 0;
	int imuR_y_pos = 0;
	int imuR_z_pos = 0;
	int imuL_x_pos = 0;
	int imuL_y_pos = 0;
	int imuL_z_pos = 0;

	int corectR = 0;
	int corectL = 0;

void dataCallbackR(const sensor_msgs::Imu::ConstPtr& msgR)
{
	
	tf::Quaternion q(msgR->orientation.x, msgR->orientation.y, msgR->orientation.z, msgR->orientation.w);
	tf::Matrix3x3 m(q);
	double roll, pitch, yaw;
	m.getRPY(roll, pitch, yaw);

//	std::cout << "Roll R: " << roll << ", Pitch R: " << pitch << ", Yaw R: " << yaw << std::endl;

	float AXR = msgR->angular_velocity.x;

	if (AXR < -10 || AXR > 10)			// move up quickly
	{
		corectR = 1;				//when right imu is on right
	}

// msg reseved
	float sensativity = 0.5;

			// add x component of message
	if (roll > -sensativity && roll < sensativity)	// imu leveled
	{
		imuR_x_pos = 0;				// set varable to level
	}
	else if (roll > sensativity)			// imu tilted forward
	{
		imuR_x_pos = 1;				// set varable to forward
	}
	else if (roll < -sensativity)			// imu tilted backward
	{
		imuR_x_pos = 2;				// set varable to backward
	}
	else						// imu is in an unknown posision
	{
		ROS_INFO("error");
	}
	
			// add y component of message
	if (pitch > -sensativity && pitch < sensativity)// imu leveled
	{
		imuR_y_pos = 0;				// set varable to level
	}
	else if (pitch > sensativity)			// imu tilted right
	{
		imuR_y_pos = 1;				// set varable to straife right
	}
	else if (pitch < -sensativity)			// imu tilted left
	{
		imuR_y_pos = 2;				// set varable to straife left
	}
	else						// imu is in an unknown posision
	{
		ROS_INFO("error");
	}

			// add z component of message
	if (yaw > -sensativity && yaw < sensativity)	// imu leveled
	{
		imuR_z_pos = 0;				// set varable to level
	}
	else if (yaw > sensativity)			// imu rotated right
	{
		imuR_z_pos = 1;				// set varable to rotate right
	}
	else if (yaw < -sensativity)			// imu rotated left
	{
		imuR_z_pos = 2;				// set varable to rotate left
	}
	else						// imu is in an unknown posision
	{
		ROS_INFO("error");
	}

}

void dataCallbackL(const sensor_msgs::Imu::ConstPtr& msgL)
{
	
	tf::Quaternion q(msgL->orientation.x, msgL->orientation.y, msgL->orientation.z, msgL->orientation.w);
	tf::Matrix3x3 m(q);
	double roll, pitch, yaw;
	m.getRPY(roll, pitch, yaw);
	
//	std::cout << "Roll L: " << roll << ", Pitch L: " << pitch << ", Yaw L: " << yaw << std::endl;

	float AXL = msgL->angular_velocity.x;

	if (AXL < -10 || AXL > 10)			// move up quickly
	{
		corectL = 1;				//when left imu is on right
	}

// msg reseved
	float sensativity = 0.5;

			// add x component of message
	if (roll > -sensativity && roll < sensativity)	// imu leveled
	{
		imuL_x_pos = 0;				// set varable to level
	}
	else if (roll > sensativity)    //Xo + 0.1)	// imu tilted forward
	{
		imuL_x_pos = 1;				// set varable to forward
	}
	else if (roll < -sensativity)			// imu tilted backward
	{
		imuL_x_pos = 2;				// set varable to backward
	}
	else						// imu is in an unknown posision
	{
		ROS_INFO("error");
	}
	
			// add y component of message
	if (pitch > -sensativity && pitch < sensativity)	// imu leveled
	{
		imuL_y_pos = 0;				// set varable to level
	}
	else if (pitch > sensativity)    //Yo + 0.1)	// imu tilted right
	{
		imuL_y_pos = 1;				// set varable to straife right
	}
	else if (pitch < -sensativity)			// imu tilted left
	{
		imuL_y_pos = 2;				// set varable to straife left
	}
	else						// imu is in an unknown posision
	{
		ROS_INFO("error");
	}

			// add z component of message
	if (yaw > -sensativity && yaw < sensativity)	// imu leveled
	{
		imuL_z_pos = 0;				// set varable to level
	}
	else if (yaw > sensativity)    //Zo + 0.1)	// imu rotated right
	{
		imuL_z_pos = 1;				// set varable to rotate right
	}
	else if (yaw < -sensativity)			// imu rotated left
	{
		imuL_z_pos = 2;				// set varable to rotate left
	}
	else						// imu is in an unknown posision
	{
		ROS_INFO("error");
	}

}


int main(int argc, char **argv)
{
  
	ros::init(argc, argv, "my_fancy_controler");

	ros::NodeHandle nh;

	ros::Subscriber Rimu = nh.subscribe("right/imu/data", 1000, dataCallbackR);
	ros::Subscriber Limu = nh.subscribe("left/imu/data", 1000, dataCallbackL);
	
	
	ros::Publisher cmd_vel_pub = nh.advertise<geometry_msgs::Twist>("cmd_vel", 1);
	
	ros::Rate loop_rate(30);

	while (ros::ok())
	{
		ROS_INFO("R = %d L = %d", corectR, corectL);
		if (corectR == 1 && corectL == 1)
		{
//			ROS_INFO("calabrate");
			corectR = 0;
			corectL = 0;
		}			
		else if (corectR == 0 && corectL == 0)
		{
			ROS_INFO("error");				
		}
		else
		{
			// as is
			ROS_INFO("as is");
			if (imuR_x_pos == 0 && imuL_x_pos == 0)
			{
				ROS_INFO("no f/b or turn");
				no_ward
				no_turn
			}
			else if (imuR_x_pos == 0)
			{
				ROS_INFO("not used");
			}
			else if (imuR_x_pos == 1 && imuL_x_pos == 1)
       			{
				ROS_INFO("back");
				backward
			}
        		else if (imuR_x_pos == 1 && imuL_x_pos == 2)
        		{
        			if (corectR == 1)
				{
        				ROS_INFO("turn right");
					turn_right
				}
				else if (corectL == 1)
				{
					ROS_INFO("turn left");
					turn_left
				}
				else
				{
					ROS_INFO("error");
				}
				
        		}
			else if (imuR_x_pos == 1)
			{
				ROS_INFO("not used");
			}
	        	else if (imuR_x_pos == 2 && imuL_x_pos == 1)
	        	{
        			if (corectR == 1)
				{
        				ROS_INFO("turn left");
					turn_left
				}
				else if (corectL == 1)
				{
					ROS_INFO("turn right");
					turn_right
				}
				else
				{
					ROS_INFO("error");
				}
			}
        		else if (imuR_x_pos == 2 && imuL_x_pos == 2)
        		{
        			ROS_INFO("forward");
				forward
        		}
			else if (imuR_x_pos == 2)
			{
				ROS_INFO("not used");
			}
			else
			{
				ROS_INFO("error");
			}
	        	
	        	if (imuR_y_pos == 0 && imuL_y_pos == 0)
	        	{
				ROS_INFO("no strafe or up down");
				no_strafe
				no_elavation
			}
	        	else if (imuR_y_pos == 0)
			{
				ROS_INFO("not used");
			}	
	        	else if (imuR_y_pos == 1 && imuL_y_pos == 1)
	        	{
				ROS_INFO("move right");
				move_right
			}
        		else if (imuR_y_pos == 1 && imuL_y_pos == 2)
        		{
        			if (corectR == 1)
				{
        				ROS_INFO("up");
					up
				}
				else if (corectL == 1)
				{
					ROS_INFO("down");
					down
				}
				else
				{
					ROS_INFO("error");
				}
        		}
	        	else if (imuR_y_pos == 2 && imuL_y_pos == 1)
	        	{
	        		if (corectR == 1)
				{
        				ROS_INFO("down");
					down
				}
				else if (corectL == 1)
				{
					ROS_INFO("up");
					up
				}
				else
				{
					ROS_INFO("error");
				}
			}
        		else if (imuR_y_pos == 2 && imuL_y_pos == 2)
        		{
				ROS_INFO("move left");
				move_left
	        	}
			else
			{
				ROS_INFO("error");
			}
/*	
	        	if (imuR_z_pos == 0)
	        	{
	        		if (imuL_z_pos == 0)
	        		{
		        		ROS_INFO("not used 1");
				}
	        		else if (imuL_z_pos == 1)
	        		{
	        			ROS_INFO("not used 2");
				}
	        		else if (imuL_z_pos == 2)
	        		{
	        			ROS_INFO("not used 3");
	        		}
				else
				{
					ROS_INFO("error");
				}
	        	}
	        	else if (imuR_z_pos == 1)
	        	{
	        		if (imuL_z_pos == 0)
	        		{
		        		ROS_INFO("not used 4");
				}
	        		else if (imuL_z_pos == 1)
	        		{
	        			ROS_INFO("not used 5");
				}
	        		else if (imuL_z_pos == 2)
	        		{
	        			ROS_INFO("not used 6");
	        		}
				else
				{
					ROS_INFO("error");
				}
	        	}
	        	else if (imuR_z_pos == 2)
	        	{
	        		if (imuL_z_pos == 0)
	        		{
		        		ROS_INFO("not used 7");
				}
	        		else if (imuL_z_pos == 1)
	        		{
	        			ROS_INFO("not used 8");
				}
	        		else if (imuL_z_pos == 2)
	        		{
	        			ROS_INFO("not used 9");
	        		}
				else
				{
					ROS_INFO("error");
				}
	        	}
			else
			{
				ROS_INFO("error");
			}
*/
		}

		cmd_vel_pub.publish(control_aray);

		ros::spinOnce();
		loop_rate.sleep();

	}

	return 0;
}

