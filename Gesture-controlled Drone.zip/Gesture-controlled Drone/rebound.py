#!/usr/bin/env python
import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy

from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
import std_srvs.srv

import sys, select, termios, tty

msg = """
Reading from the keyboard  and Publishing to Twist!	-I have rebound these so that they are more familiar
---------------------------
Moving around:
   q    w    e
   a    s    d
   z    x    c

For Holonomic mode (strafing), hold down the shift key:
---------------------------
   Q    W    E
   A    S    D
   Z    X    C

o : up (+z)
l : down (-z)


These are the key bindings for the std_msgs/Empty topics
---------------------------

t : takeoff
g : land
r : reset

This is the key binding for the std_srv topic
---------------------------

f : calibrate

anything else : stop

y/h : increase/decrease max speeds by 10%
u/j : increase/decrease only linear speed by 10%
i/k : increase/decrease only angular speed by 10%

CTRL-C to quit
"""

moveBindings = {
		'w':(1,0,0,0),
		'e':(1,0,0,-1),
		'a':(0,0,0,1),
		'd':(0,0,0,-1),
		'q':(1,0,0,1),
		'x':(-1,0,0,0),
		'c':(-1,0,0,1),
		'z':(-1,0,0,-1),
		'E':(1,-1,0,0),
		'W':(1,0,0,0),
		'A':(0,1,0,0),
		'D':(0,-1,0,0),
		'Q':(1,1,0,0),
		'X':(-1,0,0,0),
		'C':(-1,-1,0,0),
		'Z':(-1,1,0,0),
		'o':(0,0,1,0),
		'l':(0,0,-1,0),
	       }

speedBindings={
		'y':(1.1,1.1),
		'h':(.9,.9),
		'u':(1.1,1),
		'j':(.9,1),
		'i':(1,1.1),
		'k':(1,.9),
	      }

stdMessageBindings={
		't': 't', 
		'g': 'g',
		'r': 'r',
		}

stdServiceBindings={
		'f': 'f',
		}

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

speed = .5
turn = 1

def vels(speed,turn):
	return "currently:\tspeed %s\tturn %s " % (speed,turn)

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)
	
	pub = rospy.Publisher('cmd_vel', Twist, queue_size = 1)
	ptakeoff = rospy.Publisher('ardrone/takeoff', Empty, queue_size = 1)
	pland = rospy.Publisher('ardrone/land', Empty, queue_size = 1)
	preset = rospy.Publisher('ardrone/reset', Empty, queue_size = 1)
	pcalibrate = rospy.Service('imu/calibrate',std_srvs.srv.Empty, Empty)
	rospy.init_node('teleop_twist_keyboard')

	x = 0
	y = 0
	z = 0
	th = 0
	status = 0

	try:
		print msg
		print vels(speed,turn)
		while(1):
			key = getKey()
			if key in moveBindings.keys():
				x = moveBindings[key][0]
				y = moveBindings[key][1]
				z = moveBindings[key][2]
				th = moveBindings[key][3]
			elif key in speedBindings.keys():
				speed = speed * speedBindings[key][0]
				turn = turn * speedBindings[key][1]

				print vels(speed,turn)
				if (status == 14):
					print msg
				status = (status + 1) % 15
			elif key in stdMessageBindings.keys():
				if (key == 't'):
					ptakeoff.publish()
				elif (key == 'g'):
					pland.publish()
				elif (key == 'r'):
					preset.publish()
			#elif key in stdServiceBings.key():
			#	if (key == 'f'):
			#		pcalibrate.EmptyResponse()
			else:
				x = 0
				y = 0
				z = 0
				th = 0
				if (key == '\x03'):
					break

			twist = Twist()
			twist.linear.x = x*speed; twist.linear.y = y*speed; twist.linear.z = z*speed;
			twist.angular.x = 0; twist.angular.y = 0; twist.angular.z = th*turn
			pub.publish(twist)

	except:
		print e

	finally:
		twist = Twist()
		twist.linear.x = 0; twist.linear.y = 0; twist.linear.z = 0
		twist.angular.x = 0; twist.angular.y = 0; twist.angular.z = 0
		pub.publish(twist)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


